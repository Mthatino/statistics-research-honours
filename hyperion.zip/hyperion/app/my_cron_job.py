from django_cron import CronJobBase, Schedule
from app.models import Doctor, Patient

class MyCronJob(CronJobBase):
	RUN_EVERY_MINS = 120 #every 2 hours
	
	schedule = Schedule(run_every_mins=RUN_EVERY_MINS)
	code = 'app.my_cron_job'
	
	def do(self):
		pass
		patient_email = Patient.objects.only('email_address')
		doctor_email = Doctor.objects.only('email_address')
		doctor_title = Doctor.objects.only('title')
		patient_title = Patient.objects.only('title')
		doctor_last = Doctor.objects.only('last_name')
		patient_last = Patient.objects.only('last_name')
		print(patient_email+' '+doctor_email)
		