import re
import schedule
import time
from datetime import datetime
import psycopg2 as p
from clickatell.http import Http
from models import Doctor, Patient

def job():
	username = "mthatino"
	password = "Sefako3787"
	email = '+27723775995'
	apiID = "C0yjYCo2Q8CRfJqrAGqPvA=="
	con = p.connect("dbname='Research' user='postgres' host='Localhost' password='Sefako3787'")
	now = time.strftime("%c")
	cur = con.cursor()
	cur.execute("SELECT title FROM PUBLIC.APP_PATIENT WHERE appointment::date = '2017-10-06';") #postgresql statement to be executed in here
	title = Patient.objects.filter(appointment=datetime.date(2017,10,6)).values('title')
	cur.execute("SELECT initials FROM PUBLIC.APP_PATIENT WHERE appointment::date = '2017-10-06';") #postgresql statement to be executed in here
	initial = Patient.objects.filter(appointment=datetime.date(2017,10,6)).values('initials')
	cur.execute("SELECT surname FROM PUBLIC.APP_PATIENT WHERE appointment::date = '2017-10-06';") #postgresql statement to be executed in here
	last_name = Patient.objects.filter(appointment=datetime.date(2017,10,6)).values('surname')
	cur.execute("SELECT contact_details FROM PUBLIC.APP_PATIENT WHERE appointment::date = '2017-10-06';") #postgresql statement to be executed in here
	contact = Patient.objects.filter(appointment=datetime.date(2017,10,6)).values('contact_details')
	for emails in email:
		msg="Dear" + str(title) + " "+ str(last_name)+ "\n" + "\n" + "Have an appointment at the dr George Mukhari academic hospital tomorrow. if you are unable to come to the appointment please call the following number: 0219876544."
		clickatell = Http(username, password, apiID)
		response = clickatell.sendMessage([email], msg)
		for entry in response:
			print(msg)
			print(entry['id'])
			print("Message sent")
			print(entry['error'])
			print(entry['errorCode'])
		# entry['id']
		# entry['destination']
		# entry['error']
		# entry['errorCode']
	#send email info here

schedule.every().minutes.do(job)
schedule.every(1).hour.do(job)
schedule.every().day.at("19:00").do(job)
schedule.every().seconds.do(job)

while 1:
	schedule.run_pending()
	time.sleep(1)
# To clear all functions
# schedule.clear
