from __future__ import unicode_literals
from django.db import models
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.models import User
from django import forms
from django.forms import ModelForm
import csv
import psycopg2 as p

# Create your models here.
class CourseUser(User):
    """
    extension of django auth_user. Will have all particulars of
    auth_user plus added fields
    """
    user = models.OneToOneField(User, on_delete=models.CASCADE)


class Courses(models.Model):
    course_code = models.CharField(primary_key=True, max_length=50,
                                   blank=None)
    course_name = models.TextField(max_length=50)
    date_time = models.DateTimeField()

    def __str__(self):
        return self.course_code + "," + self.course_name + "," + self.date_time + self.instructor + self.price


class LoginForm(AuthenticationForm):
    username = forms.CharField(max_length=30,
                               widget=forms.TextInput(
                                   attrs={'class': 'form-control',
                                          'name': 'username','placeholder':
                                              'Username'}))
    password = forms.CharField(max_length=30,
                               widget=forms.PasswordInput(
                                   attrs={'class': 'form-control',
                                          'name': 'password', 'placeholder':
                                              'password'}))


class CourseForm(ModelForm):
    class Meta:
        model = Courses
        fields = ['course_code', 'course_name', 'date_time']

class RegisterForm(UserCreationForm):
    class Meta(UserCreationForm.Meta):
        model = CourseUser
        fields = UserCreationForm.Meta.fields + (
            'first_name', 'last_name', 'email')
class Patient(models.Model):
	id = models.IntegerField(primary_key = True)
	title = models.CharField(max_length = 4)
	initials = models.CharField(max_length = 4)
	surname = models.CharField(max_length = 30)
	contact_details = models.CharField(max_length = 100)
	appointment = models.DateTimeField()
	sp_number = models.IntegerField()
	def __str__(self):
		return self.name
	

class Doctor(models.Model):
	sp_number = models.IntegerField(primary_key = True)
	title = models.CharField(max_length = 4)
	initials = models.CharField(max_length = 4)
	surname = models.CharField(max_length = 30)
	email_address = models.CharField(max_length = 100)
	password = models.CharField(max_length = 20)
	def __str__(self):
		return self.name

class Retrieve(models.Model):
	con = p.connect("dbname='Research' user='postgres' host='Localhost' password='Sefako3787'")
	cur = con.cursor()
	cur.execute("SELECT sp_number FROM PUBLIC.DOCTORS")
	sp_num = cur.fetchall()

