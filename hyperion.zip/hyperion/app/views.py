from django.shortcuts import render, redirect, reverse
from django.views import View
from app.models import RegisterForm, CourseUser, CourseForm, Courses
from django.contrib.auth.mixins import LoginRequiredMixin
from datetime import datetime
import re
import schedule
import time
from datetime import date
import psycopg2 as p
from clickatell.http import Http
from app.models import Patient as pat



# Create your views here.
class About(View):
	template_name = 'app/index.html'
	def get(self, request, *args, **kwargs):
		return render(request, self.template_name)
class Doctor(View):
	template_name = 'app/doctor.html'
	def get(self, request, *args, **kwargs):
		posts = doc.objects.all()
		email = doc.objects.only('email_address')
		args = {'posts': posts}
		return render(request, self.template_name, args)

	def post(self, request, *args, **kwargs):
		return render(request, self.template_name)

class Patient(View):
	template_name = 'app/patient.html'
	def data(request, sp_num):
		try:
			is_title=Retrieve.objects.get(sp_num=sp_num)
		except:
			raise Http404('Requested user not found.')
		context = {"is_title": is_title}
		return render(request, self.template_name, context)
	
	def get(self, request, *args, **kwargs):
		return render(request, self.template_name)

class ELearningInfo(View):
    template_name = 'app/learning.html'

    def get(self, request, *args, **kwargs):
        return render(request, self.template_name)

    def post(self, request, *args, **kwargs):
        return render(request, self.template_name)


class RegisterUser(View):
    """
        Add user view
    """
    form_class = RegisterForm
    template_name = 'app/register.html'
    title = "Add User"
    success_msg = ''
    is_redirect = False

    def get(self, request, *args, **kwargs):

        if RegisterUser.is_redirect == True:
            self.success_msg = 'User added successfully'
            RegisterUser.is_redirect = False

        form = self.form_class()

        context = {'form': form, 'success': self.success_msg,
                   'page_title': self.title}

        return render(request, self.template_name, context)

    def post(self, request, *args, **kwargs):
        form = self.form_class(request.POST)

        if form.is_valid():
            self.handle_add_user(form)
            RegisterUser.is_redirect = True

            return redirect(reverse('register'))

        context = {'form': form, 'success': self.success_msg,
                   'page_title': self.title}

        return render(request, self.template_name, context)

    def handle_add_user(self, form):
        username = form.cleaned_data['username']
        password = form.cleaned_data['password1']
        first_name = form.cleaned_data['first_name']
        last_name = form.cleaned_data['last_name']
        email = form.cleaned_data['email']
        CourseUser.objects.create_user(username=username, email=email,
                                       password=password,
                                       first_name=first_name,
                                       last_name=last_name)


def login_redirect(request):
    course_user = CourseUser.objects.get_by_natural_key(
        request.user.username)
    request.session['username'] = course_user.username
    return redirect('dashboard')


class DashBoard(View):
    template_name = 'app/dashboard.html'
    form_class = CourseForm
    title = "Add Course"
    success_msg = ''

    def get(self, request, *args, **kwargs):
        data = Courses.objects.all()
        return render(request, self.template_name, {'data': data, 'form':
            self.form_class()})

    def post(self, request, *args, **kwargs):
        course_code = request.POST['course_code']
        course_name = request.POST['course_name']
        date_time = datetime.now()
        message = ''
        if Courses.objects.filter(course_code=course_code).count() > 0:
            message = 'Course Already Exist'
        else:
            model = Courses(course_code=course_code,
                            course_name=course_name,
                            date_time=date_time)
            model.save()
            self.success_msg = 'added successfully'
        data = Courses.objects.all()
        context = {'data': data, 'form': self.form_class, 'success':
            self.success_msg,'page_title': self.title, 'm': message}

        return render(request, self.template_name, context)

class DeleteCourse(View):
    def post(self, request, *args, **kwargs):
        Courses.objects.filter(course_code=request.POST[
            'course_code2']).delete()
        return redirect(reverse('dashboard'))

def job():
	username = "mthatino"
	password = "Sefako3787"
	email = '+27723775995'
	apiID = "C0yjYCo2Q8CRfJqrAGqPvA=="
	con = p.connect("dbname='Research' user='postgres' host='Localhost' password='Sefako3787'")
	now = time.strftime("%c")
	cur = con.cursor()
	cur.execute("SELECT title FROM PUBLIC.APP_PATIENT WHERE appointment::date = '2017-10-06';") #postgresql statement to be executed in here
	title = pat.objects.filter(appointment=date(2017,10,6)).values('title')
	cur.execute("SELECT initials FROM PUBLIC.APP_PATIENT WHERE appointment::date = '2017-10-06';") #postgresql statement to be executed in here
	initial = pat.objects.filter(appointment=date(2017,10,6)).values('initials')
	cur.execute("SELECT surname FROM PUBLIC.APP_PATIENT WHERE appointment::date = '2017-10-06';") #postgresql statement to be executed in here
	last_name = pat.objects.filter(appointment=date(2017,10,6)).values('surname')
	cur.execute("SELECT contact_details FROM PUBLIC.APP_PATIENT WHERE appointment::date = '2017-10-06';") #postgresql statement to be executed in here
	contact = pat.objects.filter(appointment=date(2017,10,6)).values('contact_details')
	for emails in email:
		msg="Dear" + str(title) + " "+ str(last_name)+ "\n" + "\n" + "Have an appointment at the dr George Mukhari academic hospital tomorrow. if you are unable to come to the appointment please call the following number: 0219876544."
		clickatell = Http(username, password, apiID)
		response = clickatell.sendMessage([email], msg)
		for entry in response:
			print(msg)
			print(entry['id'])
			print("Message sent")
			print(entry['error'])
			print(entry['errorCode'])
		# entry['id']
		# entry['destination']
		# entry['error']
		# entry['errorCode']
	#send email info here

#schedule.every().minutes.do(job)
#schedule.every().hour.do(job)
schedule.every(1).day.at("11:00").do(job)
#schedule.every().seconds.do(job)

while 1:
	schedule.run_pending()
	time.sleep(1)
# To clear all functions
# schedule.clear
