from django.conf.urls import url
from django.contrib.auth import views as auth_views
from app.models import LoginForm, RegisterForm
from app.views import Doctor, Patient, RegisterUser, DashBoard, DeleteCourse, About

urlpatterns = [
    
	url(r'^about/', About.as_view(), name='about'),
    url(r'^doctor/', Doctor.as_view(), name='doctor'),
    url(r'^patient/', Patient.as_view(), name='patient'),
    url(r'^login/', auth_views.login, {'template_name': 'app/login.html',
                                       'authentication_form': LoginForm},
        name='login'),
    url(r'^register/$', RegisterUser.as_view(), name='register'),
    url(r'^dashboard/$', DashBoard.as_view(), name='dashboard'),
    url(r'^logout/$', auth_views.logout, {'next_page': '/'}, name='logout'),
    url(r'^delete/$', DeleteCourse.as_view(), {'next_page': '/'},
        name='delete'),
]
