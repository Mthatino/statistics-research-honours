import re
import schedule
import time
from datetime import datetime
import smtplib
import psycopg2 as p

def job():
	Server=smtplib.SMTP('smtp.gmail.com:587')
	Server.starttls()
	Server.login("mthatino@gmail.com","Sefako14")
	con = p.connect("dbname='Research' user='postgres' host='Localhost' password='Sefako3787'")
	now = time.strftime("%c")
	cur = con.cursor()
	cur.execute("SELECT title FROM PUBLIC.APP_PATIENT WHERE appointment = TIMESTAMP 'tomorrow';") #postgresql statement to be executed in here
	title = cur.fetchall()
	cur.execute("SELECT initials FROM PUBLIC.APP_PATIENT WHERE appointment = TIMESTAMP 'tomorrow';") #postgresql statement to be executed in here
	initial = cur.fetchall()
	cur.execute("SELECT surname FROM PUBLIC.APP_PATIENT WHERE appointment = TIMESTAMP 'tomorrow';") #postgresql statement to be executed in here
	last_name = cur.fetchall()
	cur.execute("SELECT contact_details FROM PUBLIC.APP_PATIENT WHERE appointment = TIMESTAMP 'tomorrow';") #postgresql statement to be executed in here
	email = cur.fetchall()
	cur.execute("SELECT appointment FROM PUBLIC.APP_PATIENT WHERE appointment = TIMESTAMP 'tomorrow';") #postgresql statement to be executed in here
	for appointment in cur:
		msg="Dear" + title + " "+ last_name+ "\n" + "\n" + "Have an appointment at the dr George Mukhari academic hospital on the :" + appointment + ". if you are unable to come to the appointment please call the following number: 0219876544."
		print(title)
		Server.quit()
		print("hello")
	#send email info here

schedule.every(1).minutes.do(job)
schedule.every().hour.do(job)
schedule.every().day.at("19:00").do(job)
schedule.every().seconds.do(job)

while 1:
	schedule.run_pending()
	time.sleep(1)
# To clear all functions
# schedule.clear
